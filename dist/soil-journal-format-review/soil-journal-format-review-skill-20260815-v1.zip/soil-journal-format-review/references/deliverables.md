# 交付结构与字段

## 推荐目录

```text
期刊排版审查交付/
├── 00_原稿只读副本/
├── 01_格式修订清洁版/
├── 02_格式审查批注版/
├── 03_审查记录/
│   ├── 格式审查报告.md
│   ├── 格式修改台账.csv
│   ├── 期刊规则来源.csv
│   ├── journal-profile.json
│   └── 内容保真校验.json
└── 04_验证/
    └── 交付包验证.json
```

## 格式问题字段

每条问题至少包含：

- `issue_id`：稳定编号，如 `FMT-001`；
- `location`：页码、节、表/图号、段落索引等可复核位置；
- `paragraph_index`：需要 Word 批注时的 0 起始段落索引；
- `category`：页面、文字、段落、标题、图、表、参考文献、文件等；
- `rule_id`：对应规则档案；
- `current_format`：实际观察；
- `required_format`：期刊要求；
- `action`：已修订、仅批注、无需修改、无法验证；
- `comment`：写入 Word 的格式批注；
- `status`：`OPEN`、`FIXED`、`AUTHOR_ACTION`、`UNVERIFIED`；
- `scope`：必须为 `FORMAT_ONLY`。

## 修改台账字段

CSV 列：

```text
issue_id,location,category,rule_id,before_format,after_format,action,comment_id,status
```

台账只描述格式属性，不粘贴未公开正文。

## 规则来源字段

CSV 列：

```text
rule_id,category,requirement,source_url,source_title,accessed_at,article_type,verification_status
```

`verification_status` 仅允许 `VERIFIED`、`INFERRED`、`UNVERIFIED`。

## 审查报告最低结构

1. 范围声明；
2. 目标期刊、文章类型、投稿阶段；
3. 采用的官方规则与访问日期；
4. 已修订的格式问题；
5. 仅批注/需作者处理的问题；
6. 未验证规则和冲突；
7. 内容保真校验结果；
8. 逐页视觉 QA 结果；
9. 明确列出未开展的内容审查。

## 批注要求

批注必须是真实 Word comment，锚定具体位置。批注文本应包含问题、规则要求、处理状态和来源 ID。不要使用正文着色、括号说明、脚注或文末列表替代批注。

