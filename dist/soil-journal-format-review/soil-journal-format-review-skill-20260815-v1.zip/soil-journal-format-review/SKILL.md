---
name: soil-journal-format-review
description: 按土壤学期刊及可发表土壤研究的综合、环境、农业、生态、地学等期刊当前官方要求，对 DOCX 稿件进行排版、格式合规审查、格式修订、真实 Word 批注和投稿文件检查。适用于用户要求套用目标期刊模板、核查页面/字体/标题/摘要/图表/参考文献版式/声明位置、生成格式修订稿与批注稿、复核投稿文件包等任务。只检查形式与规定项目是否存在，不评价或改写研究质量、科学内容、方法、统计、论证、语言表达、引文真实性或期刊质量。
---

# 土壤学期刊排版与格式审查

## 目标

把目标期刊的当前官方模板和作者指南转成可追溯的排版规则，交付可投稿前复核的格式修订稿、真实批注稿和校验记录。默认处理 DOCX；PDF 默认只审查不改写，LaTeX/Markdown 可在保持文本不变的前提下调整版式源码。

本 skill 不是论文评审器、语言润色器或期刊推荐器。

## 先执行硬边界

开始前必须阅读 `references/scope-boundary.md`。只要一个拟议修改可能改变研究含义，就停止该修改并标记 `OUT_OF_SCOPE_CONTENT_REVIEW`。

绝不执行以下事项：

- 评价创新性、科学性、研究价值、写作质量或录用概率；
- 审查方法、试验设计、统计、结果、讨论、结论或引用是否正确；
- 润色、改写、翻译或补写题名、摘要、正文、图表文字、声明和参考文献；
- 更改数值、单位含义、类别、范围、术语、作者顺序、机构、基金、伦理或数据声明；
- 根据影响因子、分区、核心目录、星级或历史称号评价期刊好坏。

允许检查“是否存在、是否位于规定位置、是否符合规定数量/长度/版式”，但不判断其中内容是否充分或正确。

## 确定任务模式

按用户要求选择；未指定时使用“排版修订 + 批注”模式。

1. **仅审查**：不改稿，输出格式问题清单和规则来源。
2. **排版修订 + 批注（默认）**：生成格式修订清洁版、真实 Word 批注版和修改台账。
3. **仅套用模板**：保留模板样式和稿件文本，只完成版式映射并输出保真校验。
4. **复核交付包**：检查现有稿件、图片、补充材料、声明文件和命名是否满足提交形式要求。

原文件永不覆盖。所有输出写入新的任务目录。

## 收集最少必要输入

确认或记录为未解决：

- 目标期刊准确刊名；
- 文章类型和投稿阶段（初投、返修、录用后排版）；
- 原始稿件及其附属文件；
- 用户提供的模板、投稿指南或编辑部通知；
- 是否需要双盲稿、独立题名页、行号、图表分离、补充材料；
- 需要的交付模式和批注作者名。

目标期刊或文章类型缺失时，只能做通用格式盘点，不能宣称“符合期刊要求”。期刊目录仅可用于寻找官方入口；不得把目录条目当作质量推荐。

未公开稿件优先在本地处理，不向外部服务上传全文。若只需在线核验指南，只发送期刊名、文章类型等最少元数据。

## 建立当前规则档案

阅读 `references/journal-rule-protocol.md`，再从 `assets/templates/journal-profile.json` 建立任务专用 `journal-profile.json`。

规则优先级从高到低：

1. 用户提供的编辑部明确通知；
2. 目标文章类型的当前官方模板；
3. 目标期刊当前官方作者指南；
4. 出版方当前通用投稿规范；
5. 期刊官网当前示例或近期论文，仅用于补充可见版式且必须标记为推断。

每条规则必须记录规则 ID、适用文章类型、原文位置、官方 URL、访问日期和验证状态。冲突时采用更具体、更新、离投稿环节更近的规则。不要用第三方投稿网站、旧博客或记忆补齐缺失规则；查不到就写 `UNVERIFIED`。

期刊当前要求优先于通用标准。例如目标期刊仍指定 GB/T 7714—2015 时，不得因为手头已有 GB/T 7714—2025 就自动切换。

## 检查跨平台工具与字体

任何 DOCX 修改前读取 `references/platform-tools-fonts.md` 并运行：

```bash
python3 scripts/check_toolchain.py --out toolchain.json
python3 scripts/audit_docx_fonts.py manuscript.docx --out font-audit.json
```

macOS 和 Windows 都使用相同的 OOXML 保真与批注脚本；渲染工具和字体按平台探测。本机缺少可合法分发的开源字体时，必须自动从官方固定版本下载到任务目录并校验字体与许可证；排版/渲染需要且用户未禁止时，再安装到当前用户字体目录。专有字体只走 Microsoft/Apple/Office 官方渠道，禁止第三方字体站。

开源字体下载与用户级安装：

```bash
python3 scripts/install_open_fonts.py --font noto-sans-sc \
  --download-dir fonts-cache --out font-download-receipt.json
python3 scripts/install_open_fonts.py --font noto-sans-sc \
  --install-user --out font-install-receipt.json
```

第一条用于必做的下载和哈希验证；第二条只做当前用户级安装，不写系统字体目录。用户明确要求“只下载不安装”时只执行第一条。

最终投稿 DOCX 保留期刊指定的真实字体名。本机只有替代字体时，另建“仅渲染 QA”副本；不得把替代字体副本作为正式投稿稿。只在一个平台完成检查时，不得声称双平台已验证。

## 运行排版审查

### 1. 建立基线

保留原文件副本并运行：

```bash
python3 scripts/inspect_docx.py manuscript.docx --out baseline.json --include-previews
```

将原稿渲染为逐页图像并检查所有页面。使用当前环境可靠的 DOCX 渲染器；可用时采用 LibreOffice/Poppler 的 DOCX → PDF → PNG 流程。渲染是版面检查，不能证明批注存在。

本 skill 自带跨平台入口：

```bash
python3 scripts/render_docx.py manuscript.docx --output-dir render-baseline --emit-pdf
```

### 2. 逐项审查

按 `references/format-checklist.md` 和当前 `journal-profile.json` 检查：

- 文件构成、文件名、匿名化和题名页分离；
- 页面、分节、分栏、边距、页码、行号；
- 字体、字号、字形、颜色、行距、段距、缩进和对齐；
- 标题层级、编号、顺序和样式映射；
- 摘要、关键词、声明等规定项目的存在、标签、位置和机械长度；
- 图表位置、尺寸、分辨率、题注、编号、表格线型和跨页表现；
- 参考文献的版式、编号形态、悬挂缩进和规定顺序形式；
- 投稿附属文件和格式性元数据。

不得核查摘要写得好不好、图表是否科学、文献是否真实或相关、声明内容是否正确。

将发现写入 `format-findings.json`。每条问题必须有精确位置、规则 ID、当前格式、要求格式、拟执行动作和状态。不要用“格式不规范”这类无定位结论。

### 3. 仅做最小格式修订

优先通过 Word 样式、节属性、表格属性、图片布局和题注样式完成修改。保留已有有意强调，避免全局清除直接格式导致粗体、斜体、上下标或公式含义变化。

可执行的修改包括：页面几何、段落/字符样式、标题样式、图表布局、题注格式、表格边框、行号页码、分节分栏、参考文献段落版式和投稿文件组织。

以下即使看似“顺手”也不做：改句子、统一术语、改单位、改数值精度、改引用元数据、重绘科研图、调整表中数据、补写声明、删除作者信息。双盲要求只能将原有作者信息原样移动到独立题名页，不得重写。

对可用结构化操作表达的修订，先从 `assets/templates/format-plan.json` 生成任务计划，再运行白名单修订器：

```bash
python3 scripts/apply_docx_format.py manuscript.docx format-plan.json \
  --out manuscript-格式修订清洁版.docx --receipt format-application.json
```

它只接受页面/分节、段落、字符外观和表格属性；未知字段或操作直接拒绝，并在写出前运行内容保真校验。复杂图片布局、样式表或 Word 特有字段可使用文档工具修改，但仍必须通过同一保真校验。

### 4. 添加真实 Word 批注

批注必须锚定具体位置，并说明“问题—期刊要求—处理/待确认—规则来源”。使用：

```bash
python3 scripts/add_format_comments.py manuscript.docx format-findings.json \
  --out manuscript-格式审查批注版.docx --author "排版审查"
```

禁止把方括号文字、彩色正文、脚注或文末列表冒充 Word 批注。PDF 渲染通常不显示批注，必须再运行结构检查。

对已经修订的问题，批注写明实际格式动作；对规则不清或需要作者决定的问题，只批注，不猜测修改。批注不得夹带内容质量意见。

### 5. 内容保真校验

每个 DOCX 输出都必须与原稿比较：

```bash
python3 scripts/compare_docx_content.py manuscript.docx manuscript-格式修订清洁版.docx \
  --out clean-integrity.json
python3 scripts/compare_docx_content.py manuscript.docx manuscript-格式审查批注版.docx \
  --out annotated-integrity.json
```

默认比较正文、脚注、尾注、页眉页脚可见文本以及图片、嵌入对象和图表部件。任何正文差异均为失败。只有期刊明确要求新增页码/运行信息且修改已进入台账时，才可用 `--allow-header-footer-change`，该参数永远不能放宽正文、图表或媒体校验。

### 6. 渲染、结构和交付复核

重新渲染清洁版和批注版，逐页检查：

- 无文字/图表裁切、重叠、丢字或字体替换异常；
- 标题、表格、题注、页眉页脚、分节和分页符合规则；
- 修改没有造成大块异常空白、孤行或图表错位；
- 批注版包含真实 `comments.xml`、关系、内容类型和锚点；
- 清洁版不包含内部占位符、伪批注或未解释的修改。

最后从 `assets/templates/delivery-manifest.json` 建立清单并运行：

```bash
python3 scripts/validate_format_review_bundle.py delivery-manifest.json \
  --out bundle-validation.json
```

验证失败时不得宣称完成。

## 默认交付

阅读 `references/deliverables.md`。除非用户只要其中一种，默认交付：

- 原稿副本（不覆盖）；
- `*-格式修订清洁版.docx`；
- `*-格式审查批注版.docx`；
- `格式审查报告.md`；
- `格式修改台账.csv`；
- `期刊规则来源.csv`；
- `journal-profile.json`；
- `内容保真校验.json`；
- `交付包验证.json`。

技能内部的报告、台账和来源模板分别为 `assets/templates/format-audit-report.md`、`change-ledger.csv` 和 `rule-sources.csv`；为了跨平台 ZIP 兼容使用 ASCII 文件名，生成交付包时可按上述中文文件名保存。

报告开头必须写明：本次只审查形式和投稿格式，未评价论文质量、科学内容、方法、统计、论证、语言表达或引文真实性。

## 处理非 DOCX 文件

- **PDF**：默认输出带页码定位的审查报告；除非用户明确要求，不直接改 PDF。若有可编辑源文件，优先修改源文件。
- **LaTeX**：只改类文件、宏、版面命令、浮动体和参考文献样式配置；修改前后比较正文 token，并编译检查版面。
- **Markdown**：只改结构标记和转换配置；正文文本保持不变，再生成 DOCX/PDF 做视觉核验。
- **扫描件**：可做视觉格式审查，但不能声称完成精确文本保真校验。

## 资源索引

- `references/scope-boundary.md`：允许和禁止的检查/修改边界。
- `references/journal-rule-protocol.md`：官方规则获取、版本和冲突处理。
- `references/format-checklist.md`：格式审查清单。
- `references/deliverables.md`：交付结构、问题与台账字段。
- `references/journal-registry.csv`：期刊官方入口发现表；不是质量评价表。
- `references/platform-tools-fonts.md`：macOS/Windows 工具、字体下载与双平台终检。
- `references/design-provenance.md`：实际下载的 Hemusci 参考 skill 版本和取舍记录。
- `scripts/inspect_docx.py`：DOCX 结构和格式盘点。
- `scripts/apply_docx_format.py`：按白名单计划修订 DOCX 格式并自动执行内容保真校验。
- `scripts/add_format_comments.py`：添加真实 Word 批注。
- `scripts/compare_docx_content.py`：文本、图表和媒体内容保真校验。
- `scripts/validate_journal_profile.py`：规则档案完整性和越界字段校验。
- `scripts/validate_format_review_bundle.py`：交付包总校验。
- `scripts/check_toolchain.py`：跨平台工具探测。
- `scripts/audit_docx_fonts.py`：DOCX 字体与本机字库审计。
- `scripts/install_open_fonts.py`：从固定的官方 Google Fonts 提交下载并安装开源中文字体。
- `scripts/render_docx.py`：macOS/Windows/Linux 的 DOCX → PDF/PNG 渲染入口。
- `scripts/test_skill.py`：格式修订、真实批注、命名空间与内容保真的无依赖回归测试。
