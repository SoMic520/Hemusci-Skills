#!/usr/bin/env python3
"""Audit DOCX-requested fonts against fonts installed on macOS/Windows/Linux."""

from __future__ import annotations

import argparse
import json
import platform
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"


def qn(local: str) -> str:
    return f"{{{W}}}{local}"


def normalize(name: str) -> str:
    return re.sub(r"\s+", " ", name.strip()).casefold()


def installed_from_fontconfig() -> set[str]:
    executable = shutil.which("fc-list")
    if not executable:
        return set()
    result = subprocess.run(
        [executable, "--format=%{family}\n"], capture_output=True, text=True, timeout=30, check=False
    )
    families = set()
    for line in result.stdout.splitlines():
        for family in line.split(","):
            if family.strip():
                families.add(family.strip())
    return families


def installed_from_macos() -> set[str]:
    executable = shutil.which("system_profiler")
    if not executable:
        return set()
    result = subprocess.run(
        [executable, "SPFontsDataType", "-json"],
        capture_output=True,
        text=True,
        timeout=90,
        check=False,
    )
    if result.returncode != 0:
        return set()
    payload = json.loads(result.stdout)
    families = set()
    for font_file in payload.get("SPFontsDataType", []):
        for face in font_file.get("typefaces", []):
            for key in ("family", "fullname"):
                value = face.get(key)
                if value:
                    families.add(str(value))
    return families


def installed_from_windows_registry() -> set[str]:
    try:
        import winreg  # type: ignore
    except ImportError:
        return set()
    families = set()
    locations = (
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts"),
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts"),
    )
    for hive, key_path in locations:
        try:
            key = winreg.OpenKey(hive, key_path)
        except OSError:
            continue
        with key:
            count = winreg.QueryInfoKey(key)[1]
            for index in range(count):
                display_name, _, _ = winreg.EnumValue(key, index)
                cleaned = re.sub(r"\s*\((TrueType|OpenType|All res)\)\s*$", "", display_name).strip()
                cleaned = re.sub(r"\s+(Regular|Bold|Italic|Bold Italic)\s*$", "", cleaned).strip()
                if cleaned:
                    families.add(cleaned)
    return families


def installed_fonts() -> tuple[set[str], str]:
    system = platform.system()
    families = installed_from_fontconfig()
    if families:
        return families, "fontconfig"
    if system == "Darwin":
        return installed_from_macos(), "system_profiler"
    if system == "Windows":
        return installed_from_windows_registry(), "windows_registry"
    return set(), "unavailable"


def requested_fonts(docx: Path) -> tuple[set[str], set[str]]:
    direct: set[str] = set()
    theme_references: set[str] = set()
    with zipfile.ZipFile(docx) as archive:
        parts = [
            name
            for name in archive.namelist()
            if name in {"word/document.xml", "word/styles.xml", "word/footnotes.xml", "word/endnotes.xml"}
            or name.startswith("word/header") and name.endswith(".xml")
            or name.startswith("word/footer") and name.endswith(".xml")
        ]
        for name in parts:
            root = ET.fromstring(archive.read(name))
            for r_fonts in root.iter(qn("rFonts")):
                for key in ("ascii", "hAnsi", "eastAsia", "cs"):
                    value = r_fonts.get(qn(key))
                    if value:
                        direct.add(value)
                for key in ("asciiTheme", "hAnsiTheme", "eastAsiaTheme", "cstheme"):
                    value = r_fonts.get(qn(key))
                    if value:
                        theme_references.add(value)
    return direct, theme_references


def mapping_key_for(name: str, mappings: dict[str, Any]) -> str | None:
    target = normalize(name)
    for canonical, details in mappings.items():
        if target == normalize(canonical):
            return canonical
        if any(target == normalize(alias) for alias in details.get("aliases", [])):
            return canonical
    return None


def audit(docx: Path, mapping_path: Path, extra_required: list[str]) -> dict[str, Any]:
    mapping_payload = json.loads(mapping_path.read_text(encoding="utf-8"))
    mappings = mapping_payload.get("families", {})
    requested, theme_refs = requested_fonts(docx)
    requested.update(extra_required)
    installed, detector = installed_fonts()
    installed_lookup = {normalize(name): name for name in installed}
    system_key = {"Darwin": "macos_qa", "Windows": "windows_qa"}.get(platform.system(), "linux_qa")
    rows = []
    missing_exact = 0
    missing_without_fallback = 0
    for font in sorted(requested, key=str.casefold):
        exact = installed_lookup.get(normalize(font))
        canonical = mapping_key_for(font, mappings)
        candidates = mappings.get(canonical, {}).get(system_key, []) if canonical else []
        available_fallback = next(
            (installed_lookup[normalize(candidate)] for candidate in candidates if normalize(candidate) in installed_lookup),
            None,
        )
        if not exact:
            missing_exact += 1
            if not available_fallback:
                missing_without_fallback += 1
        rows.append(
            {
                "requested": font,
                "canonical_mapping": canonical,
                "exact_installed": bool(exact),
                "installed_name": exact,
                "qa_fallback_candidates": candidates,
                "available_qa_fallback": available_fallback,
                "final_docx_policy": "retain_requested_font_name",
            }
        )
    status = "PASS"
    if missing_without_fallback:
        status = "FAIL"
    elif missing_exact:
        status = "WARN"
    return {
        "status": status,
        "platform": platform.system(),
        "font_detector": detector,
        "installed_family_count": len(installed),
        "document": str(docx.resolve()),
        "theme_font_references": sorted(theme_refs),
        "fonts": rows,
        "missing_exact_count": missing_exact,
        "missing_without_qa_fallback_count": missing_without_fallback,
        "warning": (
            "QA fallbacks must only be applied to a separate rendering copy; final DOCX retains journal fonts."
            if missing_exact
            else None
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("docx", type=Path)
    parser.add_argument("--mapping", type=Path)
    parser.add_argument("--required-font", action="append", default=[])
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    mapping = args.mapping or Path(__file__).resolve().parent.parent / "assets/font-compatibility.json"
    try:
        result = audit(args.docx, mapping, args.required_font)
    except (OSError, ValueError, json.JSONDecodeError, zipfile.BadZipFile, ET.ParseError) as exc:
        result = {"status": "ERROR", "error": str(exc)}
    payload = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(payload + "\n", encoding="utf-8")
    print(payload)
    return {"PASS": 0, "WARN": 3}.get(result.get("status"), 2)


if __name__ == "__main__":
    sys.exit(main())

