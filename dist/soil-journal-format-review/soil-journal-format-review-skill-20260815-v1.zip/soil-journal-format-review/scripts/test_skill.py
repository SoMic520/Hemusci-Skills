#!/usr/bin/env python3
"""Dependency-free regression tests for the format-only DOCX toolchain."""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from add_format_comments import add_comments, verify_comments  # noqa: E402
from apply_docx_format import apply_format  # noqa: E402
from compare_docx_content import compare_documents  # noqa: E402
from install_open_fonts import git_blob_sha1  # noqa: E402
from validate_journal_profile import validate_profile  # noqa: E402

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"


def qn(local: str) -> str:
    return f"{{{W}}}{local}"


def build_fixture(path: Path) -> None:
    content_types = b"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>"""
    root_rels = b"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""
    document_rels = b"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>"""
    document = b"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
 xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
 xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
 xmlns:w15="http://schemas.microsoft.com/office/word/2012/wordml"
 mc:Ignorable="w14 w15">
  <w:body>
    <w:p w14:paraId="00000001"><w:r><w:t>Soil title</w:t></w:r></w:p>
    <w:p><w:r><w:t>Content must remain unchanged: 1.25 mg kg-1.</w:t></w:r></w:p>
    <w:tbl><w:tblPr/><w:tr><w:tc><w:p><w:r><w:t>Table value 7</w:t></w:r></w:p></w:tc></w:tr></w:tbl>
    <w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr>
  </w:body>
</w:document>"""
    with zipfile.ZipFile(path, "w") as package:
        package.writestr("[Content_Types].xml", content_types)
        package.writestr("_rels/.rels", root_rels)
        package.writestr("word/document.xml", document)
        package.writestr("word/_rels/document.xml.rels", document_rels)


class SkillTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_context = tempfile.TemporaryDirectory(prefix="soil-format-skill-test-")
        self.temp_dir = Path(self.temp_context.name)
        self.source = self.temp_dir / "source.docx"
        build_fixture(self.source)

    def tearDown(self) -> None:
        self.temp_context.cleanup()

    def test_format_then_comment_preserves_content_and_namespaces(self) -> None:
        plan = {
            "scope": "FORMAT_ONLY",
            "operations": [
                {
                    "operation_id": "FMT-001",
                    "op": "section",
                    "section_index": "all",
                    "properties": {"margin_left_twips": 1800, "columns": 1},
                },
                {
                    "operation_id": "FMT-002",
                    "op": "paragraph",
                    "paragraph_index": 0,
                    "properties": {"alignment": "center", "keep_with_next": True},
                },
                {
                    "operation_id": "FMT-003",
                    "op": "run",
                    "paragraph_index": 0,
                    "run_index": "all",
                    "properties": {
                        "font_ascii": "Times New Roman",
                        "font_east_asia": "Noto Serif SC",
                        "font_size_half_points": 28,
                    },
                },
                {
                    "operation_id": "FMT-004",
                    "op": "table",
                    "table_index": 0,
                    "properties": {"alignment": "center", "repeat_first_row": True},
                },
            ],
        }
        plan_path = self.temp_dir / "plan.json"
        plan_path.write_text(json.dumps(plan), encoding="utf-8")
        clean = self.temp_dir / "clean.docx"
        result = apply_format(self.source, plan_path, clean)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(compare_documents(self.source, clean)["status"], "PASS")

        findings = {
            "scope": "FORMAT_ONLY",
            "findings": [
                {
                    "issue_id": "FMT-001",
                    "paragraph_index": 0,
                    "scope": "FORMAT_ONLY",
                    "comment": "仅格式：已按规则 PAGE-001 调整，正文未改。",
                }
            ],
        }
        findings_path = self.temp_dir / "findings.json"
        findings_path.write_text(json.dumps(findings, ensure_ascii=False), encoding="utf-8")
        annotated = self.temp_dir / "annotated.docx"
        add_comments(clean, findings_path, annotated, "排版审查", "FR")
        self.assertTrue(verify_comments(annotated)["valid"])
        self.assertEqual(compare_documents(self.source, annotated)["status"], "PASS")
        with zipfile.ZipFile(annotated) as package:
            xml = package.read("word/document.xml")
            ET.fromstring(xml)
            self.assertIn(b'xmlns:w15="http://schemas.microsoft.com/office/word/2012/wordml"', xml)

    def test_guard_detects_visible_text_change(self) -> None:
        changed = self.temp_dir / "changed.docx"
        with zipfile.ZipFile(self.source) as source_package, zipfile.ZipFile(changed, "w") as target:
            for info in source_package.infolist():
                data = source_package.read(info.filename)
                if info.filename == "word/document.xml":
                    data = data.replace(b"1.25", b"9.99")
                target.writestr(info, data)
        result = compare_documents(self.source, changed)
        self.assertEqual(result["status"], "FAIL")
        self.assertTrue(result["core_text"]["differences"])

    def test_profile_rejects_quality_fields(self) -> None:
        profile = {
            "journal": {
                "name": "Example Journal",
                "article_type": "Article",
                "submission_stage": "initial",
                "accessed_at": "2026-08-15",
            },
            "scope_statement": "只审查格式",
            "rules": [
                {
                    "rule_id": "PAGE-001",
                    "category": "page",
                    "requirement": "A4 纸张",
                    "applies_to": "main_manuscript",
                    "article_type": "Article",
                    "source_title": "Official guide",
                    "source_url": "https://example.org/official-guide",
                    "source_locator": "Page 1",
                    "accessed_at": "2026-08-15",
                    "verification_status": "VERIFIED",
                }
            ],
        }
        self.assertEqual(validate_profile(profile)["status"], "PASS")
        profile["journal"]["impact_factor"] = 99
        self.assertEqual(validate_profile(profile)["status"], "FAIL")

    def test_git_blob_hash_implementation(self) -> None:
        self.assertEqual(git_blob_sha1(b"test\n"), "9daeafb9864cf43055ae93beb0afd6c7d144bfa4")


if __name__ == "__main__":
    unittest.main(verbosity=2)
