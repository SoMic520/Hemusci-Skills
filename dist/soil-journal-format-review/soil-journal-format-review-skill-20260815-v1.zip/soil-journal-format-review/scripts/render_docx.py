#!/usr/bin/env python3
"""Render DOCX to PDF and per-page PNG on macOS, Windows, or Linux."""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import platform
from pathlib import Path

from check_toolchain import inspect_toolchain


def run(command: list[str], env: dict[str, str], timeout: int = 180) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, capture_output=True, text=True, env=env, timeout=timeout, check=False)


def render(docx: Path, output_dir: Path, dpi: int, emit_pdf: bool) -> dict:
    if not docx.exists() or docx.suffix.lower() != ".docx":
        raise ValueError(f"DOCX not found: {docx}")
    toolchain = inspect_toolchain()
    soffice = toolchain["tools"]["soffice"]["path"]
    raster = toolchain["tools"]["pdftoppm"]["path"] or toolchain["tools"]["pdftocairo"]["path"]
    if not soffice:
        raise RuntimeError("LibreOffice/soffice is required for DOCX rendering")
    output_dir.mkdir(parents=True, exist_ok=True)

    temp_parent = "/private/tmp" if platform.system() == "Darwin" else None
    with tempfile.TemporaryDirectory(prefix="soil-journal-render-", dir=temp_parent) as temporary:
        temp = Path(temporary)
        profile = temp / "lo-profile"
        profile.mkdir()
        working_docx = temp / "render-input.docx"
        shutil.copy2(docx.resolve(), working_docx)
        env = os.environ.copy()
        env["HOME"] = str(temp)
        env["TMPDIR"] = "/private/tmp" if platform.system() == "Darwin" else str(temp)
        if os.name == "nt":
            env["USERPROFILE"] = str(temp)
        command = [
            soffice,
            "--headless",
            "--nologo",
            "--nodefault",
            "--nofirststartwizard",
            f"-env:UserInstallation={profile.resolve().as_uri()}",
            "--convert-to",
            "pdf",
            "--outdir",
            str(temp.resolve()),
            str(working_docx.resolve()),
        ]
        conversion = run(command, env)
        converted_pdf = temp / "render-input.pdf"
        if conversion.returncode != 0 or not converted_pdf.exists() or converted_pdf.stat().st_size == 0:
            raise RuntimeError(
                "LibreOffice conversion failed: "
                + (conversion.stderr.strip() or conversion.stdout.strip() or f"exit {conversion.returncode}")
            )
        pdf = output_dir / f"{docx.stem}.pdf"
        shutil.copy2(converted_pdf, pdf)

        pages = []
        if raster:
            prefix = output_dir / "page"
            if Path(raster).name.lower().startswith("pdftocairo"):
                raster_command = [raster, "-png", "-r", str(dpi), str(pdf), str(prefix)]
            else:
                raster_command = [raster, "-png", "-r", str(dpi), str(pdf), str(prefix)]
            raster_result = run(raster_command, env)
            if raster_result.returncode != 0:
                raise RuntimeError(
                    "PDF rasterization failed: "
                    + (raster_result.stderr.strip() or raster_result.stdout.strip())
                )
            generated = sorted(
                output_dir.glob("page-*.png"),
                key=lambda path: int(re.search(r"(\d+)$", path.stem).group(1)),
            )
            pages = [str(path.resolve()) for path in generated]
        status = "PASS" if pages else "WARN"
        result = {
            "status": status,
            "docx": str(docx.resolve()),
            "pdf": str(pdf.resolve()),
            "pages": pages,
            "page_count": len(pages),
            "dpi": dpi,
            "toolchain": toolchain,
            "warning": None if pages else "PDF created, but Poppler page rasterizer was not available.",
        }
        if not emit_pdf and pages:
            pdf.unlink()
            result["pdf"] = None
        return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("docx", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--dpi", type=int, default=160)
    parser.add_argument("--emit-pdf", action="store_true")
    parser.add_argument("--out-json", type=Path)
    args = parser.parse_args()
    try:
        result = render(args.docx, args.output_dir, args.dpi, args.emit_pdf)
    except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as exc:
        result = {"status": "ERROR", "error": str(exc)}
    payload = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out_json:
        args.out_json.parent.mkdir(parents=True, exist_ok=True)
        args.out_json.write_text(payload + "\n", encoding="utf-8")
    print(payload)
    return 0 if result.get("status") in {"PASS", "WARN"} else 2


if __name__ == "__main__":
    sys.exit(main())
