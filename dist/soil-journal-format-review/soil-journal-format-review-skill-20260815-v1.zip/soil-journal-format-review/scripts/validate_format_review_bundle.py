#!/usr/bin/env python3
"""Validate a format-only journal review delivery bundle."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
import zipfile
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

from compare_docx_content import GuardError, compare_documents
from validate_journal_profile import validate_profile

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

REQUIRED_MANIFEST_KEYS = {
    "source_document",
    "clean_document",
    "annotated_document",
    "audit_report",
    "change_ledger",
    "rule_manifest",
    "journal_profile",
}
LEDGER_COLUMNS = {
    "issue_id",
    "location",
    "category",
    "rule_id",
    "before_format",
    "after_format",
    "action",
    "comment_id",
    "status",
}
RULE_COLUMNS = {
    "rule_id",
    "category",
    "requirement",
    "source_url",
    "source_title",
    "accessed_at",
    "article_type",
    "verification_status",
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def csv_columns(path: Path) -> tuple[set[str], int]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        return set(reader.fieldnames or []), sum(1 for _ in reader)


def comment_count(path: Path) -> int:
    with zipfile.ZipFile(path) as archive:
        if "word/comments.xml" not in archive.namelist():
            return 0
        root = ET.fromstring(archive.read("word/comments.xml"))
        return len(root.findall(f"{{{W}}}comment"))


def resolve_paths(manifest_path: Path, manifest: dict[str, Any]) -> dict[str, Path]:
    base = manifest_path.parent
    return {
        key: (base / str(manifest[key])).resolve()
        for key in REQUIRED_MANIFEST_KEYS
        if key in manifest
    }


def validate_bundle(manifest_path: Path) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(manifest, dict):
        return {"status": "FAIL", "errors": ["Delivery manifest must be an object"], "warnings": []}
    missing_keys = sorted(REQUIRED_MANIFEST_KEYS - set(manifest))
    if missing_keys:
        errors.append(f"Manifest missing keys: {', '.join(missing_keys)}")
    paths = resolve_paths(manifest_path, manifest)
    for key, path in paths.items():
        if not path.exists():
            errors.append(f"{key} not found: {path}")
    if errors:
        return {"status": "FAIL", "errors": errors, "warnings": warnings, "files": {}}

    source = paths["source_document"]
    clean = paths["clean_document"]
    annotated = paths["annotated_document"]
    if source.resolve() in {clean.resolve(), annotated.resolve()}:
        errors.append("Outputs must not overwrite the source document")

    allow_hf = bool(manifest.get("allow_header_footer_change", False))
    integrity: dict[str, Any] = {}
    for label, target in (("clean", clean), ("annotated", annotated)):
        try:
            result = compare_documents(source, target, allow_header_footer_change=allow_hf)
        except GuardError as exc:
            errors.append(f"{label} content guard error: {exc}")
            continue
        integrity[label] = result
        if result["status"] != "PASS":
            errors.append(f"{label} document failed content integrity")

    source_comments = comment_count(source)
    annotated_comments = comment_count(annotated)
    expect_comments = bool(manifest.get("expect_format_comments", True))
    if expect_comments and annotated_comments <= source_comments:
        errors.append(
            f"Annotated document has no new Word comments (source={source_comments}, annotated={annotated_comments})"
        )

    ledger_columns, ledger_rows = csv_columns(paths["change_ledger"])
    missing_ledger = sorted(LEDGER_COLUMNS - ledger_columns)
    if missing_ledger:
        errors.append(f"Change ledger missing columns: {', '.join(missing_ledger)}")
    if ledger_rows == 0:
        warnings.append("Change ledger has no data rows")

    rule_columns, rule_rows = csv_columns(paths["rule_manifest"])
    missing_rules = sorted(RULE_COLUMNS - rule_columns)
    if missing_rules:
        errors.append(f"Rule manifest missing columns: {', '.join(missing_rules)}")
    if rule_rows == 0:
        errors.append("Rule manifest has no data rows")

    profile = json.loads(paths["journal_profile"].read_text(encoding="utf-8"))
    profile_result = validate_profile(profile)
    if profile_result["status"] != "PASS":
        errors.extend(f"Journal profile: {message}" for message in profile_result["errors"])
    warnings.extend(f"Journal profile: {message}" for message in profile_result["warnings"])

    report_text = paths["audit_report"].read_text(encoding="utf-8")
    if len(report_text.strip()) < 120:
        errors.append("Audit report is too short to be a complete review record")
    if "未评价" not in report_text or "科学内容" not in report_text:
        errors.append("Audit report must explicitly state that scientific content was not evaluated")

    file_hashes = {key: sha256_file(path) for key, path in paths.items()}
    return {
        "status": "FAIL" if errors else "PASS",
        "scope": "FORMAT_ONLY",
        "errors": errors,
        "warnings": warnings,
        "files": {key: {"path": str(path), "sha256": file_hashes[key]} for key, path in paths.items()},
        "comments": {"source": source_comments, "annotated": annotated_comments},
        "integrity": integrity,
        "journal_profile_validation": profile_result,
        "rows": {"change_ledger": ledger_rows, "rule_manifest": rule_rows},
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    try:
        result = validate_bundle(args.manifest.resolve())
    except (OSError, ValueError, KeyError, json.JSONDecodeError, zipfile.BadZipFile, ET.ParseError) as exc:
        result = {"status": "ERROR", "errors": [str(exc)], "warnings": []}
    payload = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(payload + "\n", encoding="utf-8")
    print(payload)
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    sys.exit(main())

