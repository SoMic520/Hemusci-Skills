#!/usr/bin/env python3
"""Fail-closed content guard for format-only DOCX revisions.

The comparison ignores formatting XML and Word comments, but compares visible
manuscript text, header/footer text, scientific media, embedded objects, chart
parts, and external relationship targets. Exit code 0 means PASS, 2 means a
content difference was found, and 1 means the inputs could not be inspected.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import zipfile
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M = "http://schemas.openxmlformats.org/officeDocument/2006/math"
PR = "http://schemas.openxmlformats.org/package/2006/relationships"

W_P = f"{{{W}}}p"
W_T = f"{{{W}}}t"
M_T = f"{{{M}}}t"
W_DEL = f"{{{W}}}del"
W_MOVE_FROM = f"{{{W}}}moveFrom"

CORE_TEXT_PARTS = (
    "word/document.xml",
    "word/footnotes.xml",
    "word/endnotes.xml",
)


class GuardError(RuntimeError):
    pass


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _is_deleted(element: ET.Element, parents: dict[ET.Element, ET.Element]) -> bool:
    current = element
    while current in parents:
        current = parents[current]
        if current.tag in {W_DEL, W_MOVE_FROM}:
            return True
    return False


def extract_visible_text(xml_bytes: bytes) -> str:
    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError as exc:
        raise GuardError(f"Invalid OOXML story part: {exc}") from exc

    parents = {child: parent for parent in root.iter() for child in parent}
    paragraphs: list[str] = []
    for paragraph in root.iter(W_P):
        if _is_deleted(paragraph, parents):
            continue
        chunks: list[str] = []
        for element in paragraph.iter():
            if _is_deleted(element, parents):
                continue
            if element.tag in {W_T, M_T}:
                chunks.append(element.text or "")
                continue
            if element.tag == f"{{{W}}}tab":
                chunks.append("\t")
            elif element.tag in {f"{{{W}}}br", f"{{{W}}}cr"}:
                chunks.append("\n")
            elif element.tag == f"{{{W}}}noBreakHyphen":
                chunks.append("\u2011")
            elif element.tag == f"{{{W}}}softHyphen":
                chunks.append("\u00ad")
            elif element.tag == f"{{{W}}}sym":
                font = element.get(f"{{{W}}}font", "")
                char = element.get(f"{{{W}}}char", "")
                chunks.append(f"[SYM:{font}:{char}]")
        paragraphs.append("".join(chunks))
    return "\n".join(paragraphs)


def _first_difference(left: str, right: str, radius: int = 36) -> dict[str, Any] | None:
    limit = min(len(left), len(right))
    index = next((i for i in range(limit) if left[i] != right[i]), limit)
    if index == limit and len(left) == len(right):
        return None
    start = max(0, index - radius)
    end_left = min(len(left), index + radius)
    end_right = min(len(right), index + radius)
    return {
        "character_index": index,
        "source_context": left[start:end_left],
        "revised_context": right[start:end_right],
        "source_length": len(left),
        "revised_length": len(right),
    }


def _read_package(path: Path) -> dict[str, bytes]:
    if not path.exists():
        raise GuardError(f"File not found: {path}")
    if path.suffix.lower() != ".docx":
        raise GuardError(f"Expected .docx: {path}")
    try:
        with zipfile.ZipFile(path) as archive:
            if "word/document.xml" not in archive.namelist():
                raise GuardError(f"Not a Word DOCX package: {path}")
            return {name: archive.read(name) for name in archive.namelist() if not name.endswith("/")}
    except zipfile.BadZipFile as exc:
        raise GuardError(f"Invalid DOCX ZIP package: {path}") from exc


def _story_parts(package: dict[str, bytes]) -> tuple[list[str], list[str]]:
    core = [name for name in CORE_TEXT_PARTS if name in package]
    auxiliary = sorted(
        name
        for name in package
        if name.startswith("word/header") and name.endswith(".xml")
        or name.startswith("word/footer") and name.endswith(".xml")
    )
    return core, auxiliary


def _part_text_map(package: dict[str, bytes], names: list[str]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for name in names:
        text = extract_visible_text(package[name])
        result[name] = {
            "sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
            "characters": len(text),
            "text": text,
        }
    return result


def _binary_map(package: dict[str, bytes]) -> dict[str, dict[str, Any]]:
    prefixes = ("word/media/", "word/embeddings/", "word/charts/")
    return {
        name: {"sha256": sha256_bytes(data), "bytes": len(data)}
        for name, data in sorted(package.items())
        if name.startswith(prefixes)
    }


def _external_relationships(package: dict[str, bytes]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for name, data in sorted(package.items()):
        if not name.endswith(".rels"):
            continue
        try:
            root = ET.fromstring(data)
        except ET.ParseError:
            continue
        for rel in root.findall(f"{{{PR}}}Relationship"):
            if rel.get("TargetMode") != "External":
                continue
            rows.append(
                {
                    "part": name,
                    "type": rel.get("Type", ""),
                    "target": rel.get("Target", ""),
                }
            )
    return rows


def compare_documents(
    source: Path,
    revised: Path,
    *,
    allow_header_footer_change: bool = False,
) -> dict[str, Any]:
    source_package = _read_package(source)
    revised_package = _read_package(revised)

    source_core_names, source_aux_names = _story_parts(source_package)
    revised_core_names, revised_aux_names = _story_parts(revised_package)
    all_core_names = sorted(set(source_core_names) | set(revised_core_names))
    all_aux_names = sorted(set(source_aux_names) | set(revised_aux_names))

    source_core = _part_text_map(source_package, [n for n in all_core_names if n in source_package])
    revised_core = _part_text_map(revised_package, [n for n in all_core_names if n in revised_package])
    source_aux = _part_text_map(source_package, [n for n in all_aux_names if n in source_package])
    revised_aux = _part_text_map(revised_package, [n for n in all_aux_names if n in revised_package])

    text_differences: list[dict[str, Any]] = []
    for name in all_core_names:
        left = source_core.get(name, {}).get("text", "")
        right = revised_core.get(name, {}).get("text", "")
        difference = _first_difference(left, right)
        if difference or (name in source_core) != (name in revised_core):
            text_differences.append({"part": name, **(difference or {"part_presence_changed": True})})

    auxiliary_differences: list[dict[str, Any]] = []
    for name in all_aux_names:
        left = source_aux.get(name, {}).get("text", "")
        right = revised_aux.get(name, {}).get("text", "")
        difference = _first_difference(left, right)
        if difference or (name in source_aux) != (name in revised_aux):
            auxiliary_differences.append({"part": name, **(difference or {"part_presence_changed": True})})

    source_binary = _binary_map(source_package)
    revised_binary = _binary_map(revised_package)
    binary_differences = []
    for name in sorted(set(source_binary) | set(revised_binary)):
        if source_binary.get(name) != revised_binary.get(name):
            binary_differences.append(
                {"part": name, "source": source_binary.get(name), "revised": revised_binary.get(name)}
            )

    source_external = _external_relationships(source_package)
    revised_external = _external_relationships(revised_package)
    external_changed = source_external != revised_external

    failed = bool(text_differences or binary_differences or external_changed)
    if auxiliary_differences and not allow_header_footer_change:
        failed = True

    def public_map(mapping: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
        return {name: {k: v for k, v in values.items() if k != "text"} for name, values in mapping.items()}

    return {
        "status": "FAIL" if failed else "PASS",
        "scope": "FORMAT_ONLY_CONTENT_GUARD",
        "source": str(source.resolve()),
        "revised": str(revised.resolve()),
        "source_file_sha256": sha256_bytes(source.read_bytes()),
        "revised_file_sha256": sha256_bytes(revised.read_bytes()),
        "core_text": {
            "source": public_map(source_core),
            "revised": public_map(revised_core),
            "differences": text_differences,
        },
        "headers_footers": {
            "allowed_to_change": allow_header_footer_change,
            "source": public_map(source_aux),
            "revised": public_map(revised_aux),
            "differences": auxiliary_differences,
        },
        "scientific_binary_parts": {
            "source": source_binary,
            "revised": revised_binary,
            "differences": binary_differences,
        },
        "external_relationships": {
            "source": source_external,
            "revised": revised_external,
            "changed": external_changed,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("revised", type=Path)
    parser.add_argument("--out", type=Path, help="Write the JSON result to this path")
    parser.add_argument(
        "--allow-header-footer-change",
        action="store_true",
        help="Allow visible header/footer changes; body, media and links remain strict",
    )
    args = parser.parse_args()

    try:
        result = compare_documents(
            args.source,
            args.revised,
            allow_header_footer_change=args.allow_header_footer_change,
        )
    except GuardError as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False, indent=2))
        return 1

    payload = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(payload + "\n", encoding="utf-8")
    print(payload)
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    sys.exit(main())

