#!/usr/bin/env python3
"""Apply allowlisted DOCX formatting operations and fail if visible content changes."""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

from add_format_comments import _parse_xml, _serialize
from compare_docx_content import GuardError, compare_documents

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"


def qn(local: str) -> str:
    return f"{{{W}}}{local}"


def _child(parent: ET.Element, local: str) -> ET.Element:
    element = parent.find(qn(local))
    return element if element is not None else ET.SubElement(parent, qn(local))


def _set_val(parent: ET.Element, local: str, value: Any, attribute: str = "val") -> None:
    _child(parent, local).set(qn(attribute), str(value))


def _set_on_off(parent: ET.Element, local: str, value: bool) -> None:
    _child(parent, local).set(qn("val"), "1" if value else "0")


def _expect_keys(value: dict[str, Any], allowed: set[str], label: str) -> None:
    unknown = sorted(set(value) - allowed)
    if unknown:
        raise ValueError(f"{label}: unsupported keys: {', '.join(unknown)}")


def _nonnegative_int(value: Any, label: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{label} must be a non-negative integer")
    return value


def _paragraph_properties(paragraph: ET.Element, properties: dict[str, Any]) -> None:
    allowed = {
        "style_id",
        "alignment",
        "spacing_before_twips",
        "spacing_after_twips",
        "line_twips",
        "line_rule",
        "first_line_twips",
        "hanging_twips",
        "left_twips",
        "right_twips",
        "keep_with_next",
        "keep_lines",
        "page_break_before",
        "widow_control",
    }
    _expect_keys(properties, allowed, "paragraph properties")
    p_pr = paragraph.find(qn("pPr"))
    if p_pr is None:
        p_pr = ET.Element(qn("pPr"))
        paragraph.insert(0, p_pr)
    if "style_id" in properties:
        _set_val(p_pr, "pStyle", properties["style_id"])
    if "alignment" in properties:
        alignment = str(properties["alignment"])
        if alignment not in {"left", "center", "right", "both", "distribute"}:
            raise ValueError(f"Unsupported paragraph alignment: {alignment}")
        _set_val(p_pr, "jc", alignment)

    spacing_fields = {
        "spacing_before_twips": "before",
        "spacing_after_twips": "after",
        "line_twips": "line",
        "line_rule": "lineRule",
    }
    if any(name in properties for name in spacing_fields):
        spacing = _child(p_pr, "spacing")
        for name, attribute in spacing_fields.items():
            if name not in properties:
                continue
            value = properties[name]
            if name == "line_rule":
                if value not in {"auto", "atLeast", "exact"}:
                    raise ValueError("line_rule must be auto, atLeast, or exact")
            else:
                value = _nonnegative_int(value, name)
            spacing.set(qn(attribute), str(value))

    indent_fields = {
        "first_line_twips": "firstLine",
        "hanging_twips": "hanging",
        "left_twips": "left",
        "right_twips": "right",
    }
    if any(name in properties for name in indent_fields):
        if "first_line_twips" in properties and "hanging_twips" in properties:
            raise ValueError("first_line_twips and hanging_twips are mutually exclusive")
        ind = _child(p_pr, "ind")
        for name, attribute in indent_fields.items():
            if name in properties:
                ind.set(qn(attribute), str(_nonnegative_int(properties[name], name)))

    for name, local in {
        "keep_with_next": "keepNext",
        "keep_lines": "keepLines",
        "page_break_before": "pageBreakBefore",
        "widow_control": "widowControl",
    }.items():
        if name in properties:
            if not isinstance(properties[name], bool):
                raise ValueError(f"{name} must be boolean")
            _set_on_off(p_pr, local, properties[name])


def _run_properties(run: ET.Element, properties: dict[str, Any]) -> None:
    allowed = {
        "font_ascii",
        "font_hansi",
        "font_east_asia",
        "font_cs",
        "font_size_half_points",
        "bold",
        "italic",
        "color",
        "vertical_alignment",
    }
    _expect_keys(properties, allowed, "run properties")
    r_pr = run.find(qn("rPr"))
    if r_pr is None:
        r_pr = ET.Element(qn("rPr"))
        run.insert(0, r_pr)
    font_fields = {
        "font_ascii": "ascii",
        "font_hansi": "hAnsi",
        "font_east_asia": "eastAsia",
        "font_cs": "cs",
    }
    if any(name in properties for name in font_fields):
        fonts = _child(r_pr, "rFonts")
        for name, attribute in font_fields.items():
            if name in properties:
                value = str(properties[name]).strip()
                if not value:
                    raise ValueError(f"{name} cannot be empty")
                fonts.set(qn(attribute), value)
    if "font_size_half_points" in properties:
        size = _nonnegative_int(properties["font_size_half_points"], "font_size_half_points")
        if size == 0:
            raise ValueError("font_size_half_points must be greater than zero")
        _set_val(r_pr, "sz", size)
        _set_val(r_pr, "szCs", size)
    for name, local in {"bold": "b", "italic": "i"}.items():
        if name in properties:
            if not isinstance(properties[name], bool):
                raise ValueError(f"{name} must be boolean")
            _set_on_off(r_pr, local, properties[name])
    if "color" in properties:
        color = str(properties["color"]).upper().lstrip("#")
        if not re.fullmatch(r"[0-9A-F]{6}", color):
            raise ValueError("color must be a 6-digit hexadecimal RGB value")
        _set_val(r_pr, "color", color)
    if "vertical_alignment" in properties:
        value = properties["vertical_alignment"]
        if value not in {"baseline", "superscript", "subscript"}:
            raise ValueError("vertical_alignment must be baseline, superscript, or subscript")
        _set_val(r_pr, "vertAlign", value)


def _section_properties(section: ET.Element, properties: dict[str, Any]) -> None:
    allowed = {
        "page_width_twips",
        "page_height_twips",
        "orientation",
        "margin_top_twips",
        "margin_right_twips",
        "margin_bottom_twips",
        "margin_left_twips",
        "header_twips",
        "footer_twips",
        "gutter_twips",
        "columns",
        "column_space_twips",
    }
    _expect_keys(properties, allowed, "section properties")
    if any(name in properties for name in ("page_width_twips", "page_height_twips", "orientation")):
        page = _child(section, "pgSz")
        for name, attribute in {"page_width_twips": "w", "page_height_twips": "h"}.items():
            if name in properties:
                page.set(qn(attribute), str(_nonnegative_int(properties[name], name)))
        if "orientation" in properties:
            orientation = properties["orientation"]
            if orientation not in {"portrait", "landscape"}:
                raise ValueError("orientation must be portrait or landscape")
            page.set(qn("orient"), orientation)
    margin_fields = {
        "margin_top_twips": "top",
        "margin_right_twips": "right",
        "margin_bottom_twips": "bottom",
        "margin_left_twips": "left",
        "header_twips": "header",
        "footer_twips": "footer",
        "gutter_twips": "gutter",
    }
    if any(name in properties for name in margin_fields):
        margins = _child(section, "pgMar")
        for name, attribute in margin_fields.items():
            if name in properties:
                margins.set(qn(attribute), str(_nonnegative_int(properties[name], name)))
    if "columns" in properties or "column_space_twips" in properties:
        columns = _child(section, "cols")
        if "columns" in properties:
            count = _nonnegative_int(properties["columns"], "columns")
            if count < 1:
                raise ValueError("columns must be at least 1")
            columns.set(qn("num"), str(count))
        if "column_space_twips" in properties:
            columns.set(
                qn("space"),
                str(_nonnegative_int(properties["column_space_twips"], "column_space_twips")),
            )


def _table_properties(table: ET.Element, properties: dict[str, Any]) -> None:
    allowed = {"alignment", "width_twips", "autofit", "repeat_first_row"}
    _expect_keys(properties, allowed, "table properties")
    tbl_pr = table.find(qn("tblPr"))
    if tbl_pr is None:
        tbl_pr = ET.Element(qn("tblPr"))
        table.insert(0, tbl_pr)
    if "alignment" in properties:
        alignment = properties["alignment"]
        if alignment not in {"left", "center", "right"}:
            raise ValueError("table alignment must be left, center, or right")
        _set_val(tbl_pr, "jc", alignment)
    if "width_twips" in properties:
        width = _nonnegative_int(properties["width_twips"], "width_twips")
        tbl_w = _child(tbl_pr, "tblW")
        tbl_w.set(qn("type"), "dxa")
        tbl_w.set(qn("w"), str(width))
    if "autofit" in properties:
        if not isinstance(properties["autofit"], bool):
            raise ValueError("autofit must be boolean")
        _set_val(tbl_pr, "tblLayout", "autofit" if properties["autofit"] else "fixed", "type")
    if "repeat_first_row" in properties:
        if not isinstance(properties["repeat_first_row"], bool):
            raise ValueError("repeat_first_row must be boolean")
        first_row = table.find(qn("tr"))
        if first_row is None:
            raise ValueError("Cannot set repeat_first_row on a table with no rows")
        tr_pr = first_row.find(qn("trPr"))
        if tr_pr is None:
            tr_pr = ET.Element(qn("trPr"))
            first_row.insert(0, tr_pr)
        _set_on_off(tr_pr, "tblHeader", properties["repeat_first_row"])


def _indices(target: Any, count: int, label: str) -> list[int]:
    if target == "all":
        return list(range(count))
    index = _nonnegative_int(target, label)
    if index >= count:
        raise ValueError(f"{label} {index} is out of range (count={count})")
    return [index]


def apply_operations(document: ET.Element, plan: dict[str, Any]) -> list[dict[str, Any]]:
    if plan.get("scope") != "FORMAT_ONLY":
        raise ValueError("Format plan scope must be FORMAT_ONLY")
    operations = plan.get("operations")
    if not isinstance(operations, list) or not operations:
        raise ValueError("Format plan operations must be a non-empty list")
    paragraphs = list(document.iter(qn("p")))
    sections = list(document.iter(qn("sectPr")))
    tables = list(document.iter(qn("tbl")))
    applied: list[dict[str, Any]] = []

    for number, operation in enumerate(operations, start=1):
        if not isinstance(operation, dict):
            raise ValueError(f"operations[{number - 1}] must be an object")
        _expect_keys(
            operation,
            {"operation_id", "op", "paragraph_index", "run_index", "section_index", "table_index", "properties"},
            f"operations[{number - 1}]",
        )
        operation_id = str(operation.get("operation_id") or f"OP-{number:03d}")
        op = operation.get("op")
        properties = operation.get("properties")
        if not isinstance(properties, dict) or not properties:
            raise ValueError(f"{operation_id}: properties must be a non-empty object")

        if op == "paragraph":
            index = _indices(operation.get("paragraph_index"), len(paragraphs), "paragraph_index")[0]
            _paragraph_properties(paragraphs[index], properties)
            target = {"paragraph_index": index}
        elif op == "run":
            p_index = _indices(operation.get("paragraph_index"), len(paragraphs), "paragraph_index")[0]
            runs = list(paragraphs[p_index].iter(qn("r")))
            run_indices = _indices(operation.get("run_index", "all"), len(runs), "run_index")
            if not run_indices:
                raise ValueError(f"{operation_id}: target paragraph has no runs")
            for run_index in run_indices:
                _run_properties(runs[run_index], properties)
            target = {"paragraph_index": p_index, "run_indices": run_indices}
        elif op == "section":
            section_indices = _indices(operation.get("section_index", "all"), len(sections), "section_index")
            if not section_indices:
                raise ValueError(f"{operation_id}: document has no sections")
            for section_index in section_indices:
                _section_properties(sections[section_index], properties)
            target = {"section_indices": section_indices}
        elif op == "table":
            table_index = _indices(operation.get("table_index"), len(tables), "table_index")[0]
            _table_properties(tables[table_index], properties)
            target = {"table_index": table_index}
        else:
            raise ValueError(f"{operation_id}: unsupported op {op!r}")
        applied.append({"operation_id": operation_id, "op": op, **target, "properties": properties})
    return applied


def apply_format(source: Path, plan_path: Path, output: Path) -> dict[str, Any]:
    if source.resolve() == output.resolve():
        raise ValueError("Output must not overwrite the source DOCX")
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    with zipfile.ZipFile(source) as archive:
        infos = archive.infolist()
        parts = {info.filename: archive.read(info.filename) for info in infos if not info.is_dir()}
    document, namespaces = _parse_xml(parts["word/document.xml"])
    applied = apply_operations(document, plan)
    parts["word/document.xml"] = _serialize(document, namespaces)

    output.parent.mkdir(parents=True, exist_ok=True)
    handle, temporary_name = tempfile.mkstemp(prefix="format-revision-", suffix=".docx", dir=output.parent)
    os.close(handle)
    try:
        with zipfile.ZipFile(temporary_name, "w") as target:
            for info in infos:
                target.writestr(info, b"" if info.is_dir() else parts[info.filename])
        guard = compare_documents(source, Path(temporary_name))
        if guard["status"] != "PASS":
            raise ValueError("Content guard rejected the formatted DOCX")
        os.replace(temporary_name, output)
    finally:
        if os.path.exists(temporary_name):
            os.unlink(temporary_name)
    return {
        "status": "PASS",
        "scope": "FORMAT_ONLY",
        "source": str(source.resolve()),
        "output": str(output.resolve()),
        "operations_applied": applied,
        "content_guard": guard,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("plan", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--receipt", type=Path)
    args = parser.parse_args()
    try:
        result = apply_format(args.source, args.plan, args.out)
    except (
        FileNotFoundError,
        KeyError,
        ValueError,
        GuardError,
        zipfile.BadZipFile,
        ET.ParseError,
        json.JSONDecodeError,
    ) as exc:
        result = {"status": "ERROR", "error": str(exc)}
    payload = json.dumps(result, ensure_ascii=False, indent=2)
    if args.receipt:
        args.receipt.parent.mkdir(parents=True, exist_ok=True)
        args.receipt.write_text(payload + "\n", encoding="utf-8")
    print(payload)
    return 0 if result.get("status") == "PASS" else 2


if __name__ == "__main__":
    sys.exit(main())
