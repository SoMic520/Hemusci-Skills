#!/usr/bin/env python3
"""Validate a source-backed, format-only journal profile."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
ALLOWED_STATUS = {"VERIFIED", "INFERRED", "UNVERIFIED"}
FORBIDDEN_KEYS = {
    "quality",
    "journal_quality",
    "scientific_quality",
    "impact_factor",
    "quartile",
    "rank",
    "ranking",
    "star",
    "core_status",
    "recommendation",
    "acceptance_probability",
}
FORBIDDEN_REVIEW_PHRASES = {
    "创新性",
    "科学性",
    "研究质量",
    "写作质量",
    "统计正确",
    "方法合理",
    "引文真实性",
    "录用概率",
    "期刊质量",
}
REQUIRED_RULE_FIELDS = {
    "rule_id",
    "category",
    "requirement",
    "applies_to",
    "article_type",
    "source_title",
    "source_url",
    "source_locator",
    "accessed_at",
    "verification_status",
}


def _walk_keys(value: Any, path: str = "$") -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    if isinstance(value, dict):
        for key, child in value.items():
            rows.append((f"{path}.{key}", str(key).lower()))
            rows.extend(_walk_keys(child, f"{path}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            rows.extend(_walk_keys(child, f"{path}[{index}]"))
    return rows


def validate_profile(profile: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    if not isinstance(profile, dict):
        return {"status": "FAIL", "errors": ["Profile root must be an object"], "warnings": []}

    for path, key in _walk_keys(profile):
        if key in FORBIDDEN_KEYS:
            errors.append(f"Out-of-scope journal/content evaluation field: {path}")

    journal = profile.get("journal")
    if not isinstance(journal, dict):
        errors.append("journal must be an object")
    else:
        for field in ("name", "article_type", "submission_stage", "accessed_at"):
            if not str(journal.get(field, "")).strip():
                errors.append(f"journal.{field} is required")
        accessed = str(journal.get("accessed_at", ""))
        if accessed and not DATE_RE.match(accessed):
            errors.append("journal.accessed_at must use YYYY-MM-DD")

    scope_statement = str(profile.get("scope_statement", ""))
    if "Format-only" not in scope_statement and "只" not in scope_statement:
        warnings.append("scope_statement should explicitly say the review is format-only")

    rules = profile.get("rules")
    if not isinstance(rules, list) or not rules:
        errors.append("rules must be a non-empty list")
        rules = []
    seen_ids: set[str] = set()
    for index, rule in enumerate(rules):
        prefix = f"rules[{index}]"
        if not isinstance(rule, dict):
            errors.append(f"{prefix} must be an object")
            continue
        missing = [field for field in REQUIRED_RULE_FIELDS if not str(rule.get(field, "")).strip()]
        if missing:
            errors.append(f"{prefix} missing fields: {', '.join(sorted(missing))}")
        rule_id = str(rule.get("rule_id", ""))
        if rule_id in seen_ids:
            errors.append(f"Duplicate rule_id: {rule_id}")
        seen_ids.add(rule_id)
        status = str(rule.get("verification_status", ""))
        if status not in ALLOWED_STATUS:
            errors.append(f"{prefix}.verification_status must be one of {sorted(ALLOWED_STATUS)}")
        source_url = str(rule.get("source_url", ""))
        if status in {"VERIFIED", "INFERRED"} and not source_url.startswith(("https://", "http://")):
            errors.append(f"{prefix}.source_url must be an official HTTP(S) URL")
        accessed = str(rule.get("accessed_at", ""))
        if accessed and not DATE_RE.match(accessed):
            errors.append(f"{prefix}.accessed_at must use YYYY-MM-DD")
        requirement = str(rule.get("requirement", ""))
        for phrase in FORBIDDEN_REVIEW_PHRASES:
            if phrase in requirement:
                errors.append(f"{prefix} contains out-of-scope review phrase: {phrase}")

    return {"status": "FAIL" if errors else "PASS", "errors": errors, "warnings": warnings}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("profile", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    try:
        profile = json.loads(args.profile.read_text(encoding="utf-8"))
        result = validate_profile(profile)
    except (OSError, json.JSONDecodeError) as exc:
        result = {"status": "ERROR", "errors": [str(exc)], "warnings": []}
    payload = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(payload + "\n", encoding="utf-8")
    print(payload)
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    sys.exit(main())

