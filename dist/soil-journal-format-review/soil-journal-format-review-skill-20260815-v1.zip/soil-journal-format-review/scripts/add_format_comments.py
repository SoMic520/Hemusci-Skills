#!/usr/bin/env python3
"""Add true Word comments for format-only findings without changing visible text."""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from xml.etree import ElementTree as ET

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PR = "http://schemas.openxmlformats.org/package/2006/relationships"
CT = "http://schemas.openxmlformats.org/package/2006/content-types"
XML = "http://www.w3.org/XML/1998/namespace"

ET.register_namespace("w", W)
ET.register_namespace("r", R)


def qn(local: str) -> str:
    return f"{{{W}}}{local}"


def _load_findings(path: Path) -> list[dict]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(payload, dict):
        if payload.get("scope") not in {None, "FORMAT_ONLY"}:
            raise ValueError("Top-level scope must be FORMAT_ONLY")
        findings = payload.get("findings")
    else:
        findings = payload
    if not isinstance(findings, list):
        raise ValueError("Findings JSON must be a list or an object with a findings list")
    seen: set[int] = set()
    for finding in findings:
        if not isinstance(finding, dict):
            raise ValueError("Each finding must be an object")
        if finding.get("scope") not in {None, "FORMAT_ONLY"}:
            raise ValueError(f"{finding.get('issue_id', 'finding')}: scope must be FORMAT_ONLY")
        if not isinstance(finding.get("paragraph_index"), int) or finding["paragraph_index"] < 0:
            raise ValueError(f"{finding.get('issue_id', 'finding')}: paragraph_index must be >= 0")
        if finding["paragraph_index"] in seen:
            raise ValueError("Use one consolidated format comment per paragraph_index")
        seen.add(finding["paragraph_index"])
        if not str(finding.get("comment", "")).strip():
            raise ValueError(f"{finding.get('issue_id', 'finding')}: comment is required")
    return findings


def _paragraph_visible_text(paragraph: ET.Element) -> str:
    return "".join(element.text or "" for element in paragraph.iter(qn("t")))


def _existing_ids(document: ET.Element, comments: ET.Element | None) -> set[int]:
    ids: set[int] = set()
    for element in document.iter():
        value = element.get(qn("id"))
        if value is not None and value.lstrip("-").isdigit():
            ids.add(int(value))
    if comments is not None:
        for element in comments.findall(qn("comment")):
            value = element.get(qn("id"))
            if value is not None and value.lstrip("-").isdigit():
                ids.add(int(value))
    return ids


def _next_id(used: set[int]) -> int:
    candidate = max(used, default=-1) + 1
    while candidate in used:
        candidate += 1
    used.add(candidate)
    return candidate


def _comment_body(comment_id: int, author: str, initials: str, text: str, date: str) -> ET.Element:
    comment = ET.Element(
        qn("comment"),
        {qn("id"): str(comment_id), qn("author"): author, qn("initials"): initials, qn("date"): date},
    )
    paragraph = ET.SubElement(comment, qn("p"))
    p_pr = ET.SubElement(paragraph, qn("pPr"))
    ET.SubElement(p_pr, qn("pStyle"), {qn("val"): "CommentText"})
    reference_run = ET.SubElement(paragraph, qn("r"))
    r_pr = ET.SubElement(reference_run, qn("rPr"))
    ET.SubElement(r_pr, qn("rStyle"), {qn("val"): "CommentReference"})
    ET.SubElement(reference_run, qn("annotationRef"))
    text_run = ET.SubElement(paragraph, qn("r"))
    text_element = ET.SubElement(text_run, qn("t"), {f"{{{XML}}}space": "preserve"})
    text_element.text = text
    return comment


def _ensure_comments_relationship(rels: ET.Element) -> None:
    comment_type = f"{R}/comments"
    if any(rel.get("Type") == comment_type for rel in rels.findall(f"{{{PR}}}Relationship")):
        return
    ids = []
    for rel in rels.findall(f"{{{PR}}}Relationship"):
        rid = rel.get("Id", "")
        if rid.startswith("rId") and rid[3:].isdigit():
            ids.append(int(rid[3:]))
    ET.SubElement(
        rels,
        f"{{{PR}}}Relationship",
        {"Id": f"rId{max(ids, default=0) + 1}", "Type": comment_type, "Target": "comments.xml"},
    )


def _ensure_content_type(content_types: ET.Element) -> None:
    part_name = "/word/comments.xml"
    if any(item.get("PartName") == part_name for item in content_types.findall(f"{{{CT}}}Override")):
        return
    ET.SubElement(
        content_types,
        f"{{{CT}}}Override",
        {
            "PartName": part_name,
            "ContentType": "application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml",
        },
    )


def _parse_xml(data: bytes) -> tuple[ET.Element, dict[str, str]]:
    """Parse XML while retaining the prefix map needed by mc:Ignorable.

    ElementTree normally drops unused namespace declarations. Word documents
    often list those prefixes in mc:Ignorable, so dropping them creates XML
    that some consumers (notably LibreOffice) reject as malformed.
    """
    namespaces: dict[str, str] = {}
    for _, (prefix, uri) in ET.iterparse(BytesIO(data), events=("start-ns",)):
        namespaces.setdefault(prefix, uri)
    return ET.fromstring(data), namespaces


def _used_namespace_uris(root: ET.Element) -> set[str]:
    used: set[str] = set()
    for element in root.iter():
        if element.tag.startswith("{"):
            used.add(element.tag[1:].split("}", 1)[0])
        for name in element.attrib:
            if name.startswith("{"):
                used.add(name[1:].split("}", 1)[0])
    return used


def _serialize(root: ET.Element, namespaces: dict[str, str] | None = None) -> bytes:
    namespaces = dict(namespaces or {})
    for prefix, uri in namespaces.items():
        if prefix in {"xml", "xmlns"} or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]*|", prefix):
            continue
        try:
            ET.register_namespace(prefix, uri)
        except ValueError:
            # ElementTree reserves prefixes such as ns0 for its own serializer.
            continue

    ignorable_name = "{http://schemas.openxmlformats.org/markup-compatibility/2006}Ignorable"
    used_uris = _used_namespace_uris(root)
    for prefix in root.get(ignorable_name, "").split():
        uri = namespaces.get(prefix)
        if uri and uri not in used_uris:
            # Preserve a declaration even when its namespace has no Clark-name
            # element/attribute in this part. mc:Ignorable still references it.
            root.set(f"xmlns:{prefix}", uri)
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def add_comments(source: Path, findings_path: Path, output: Path, author: str, initials: str) -> dict:
    if source.resolve() == output.resolve():
        raise ValueError("Output must not overwrite the source DOCX")
    findings = _load_findings(findings_path)
    with zipfile.ZipFile(source) as archive:
        infos = archive.infolist()
        parts = {info.filename: archive.read(info.filename) for info in infos if not info.is_dir()}

    document, document_namespaces = _parse_xml(parts["word/document.xml"])
    paragraphs = list(document.iter(qn("p")))
    if "word/comments.xml" in parts:
        comments, comments_namespaces = _parse_xml(parts["word/comments.xml"])
    else:
        comments = ET.Element(qn("comments"))
        comments_namespaces = {"w": W}
    rels, rels_namespaces = _parse_xml(parts["word/_rels/document.xml.rels"])
    content_types, content_type_namespaces = _parse_xml(parts["[Content_Types].xml"])
    used_ids = _existing_ids(document, comments)
    now = datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    added = []

    for finding in findings:
        index = finding["paragraph_index"]
        if index >= len(paragraphs):
            raise ValueError(f"paragraph_index {index} is out of range (paragraphs={len(paragraphs)})")
        paragraph = paragraphs[index]
        if not _paragraph_visible_text(paragraph):
            raise ValueError(f"paragraph_index {index} has no visible text; choose a non-empty anchor")
        comment_id = _next_id(used_ids)
        children = list(paragraph)
        insert_at = 1 if children and children[0].tag == qn("pPr") else 0
        paragraph.insert(insert_at, ET.Element(qn("commentRangeStart"), {qn("id"): str(comment_id)}))
        paragraph.append(ET.Element(qn("commentRangeEnd"), {qn("id"): str(comment_id)}))
        reference_run = ET.SubElement(paragraph, qn("r"))
        r_pr = ET.SubElement(reference_run, qn("rPr"))
        ET.SubElement(r_pr, qn("rStyle"), {qn("val"): "CommentReference"})
        ET.SubElement(reference_run, qn("commentReference"), {qn("id"): str(comment_id)})
        comments.append(_comment_body(comment_id, author, initials, str(finding["comment"]), now))
        added.append(
            {
                "issue_id": finding.get("issue_id"),
                "paragraph_index": index,
                "comment_id": comment_id,
            }
        )

    _ensure_comments_relationship(rels)
    _ensure_content_type(content_types)
    parts["word/document.xml"] = _serialize(document, document_namespaces)
    parts["word/comments.xml"] = _serialize(comments, comments_namespaces)
    parts["word/_rels/document.xml.rels"] = _serialize(rels, rels_namespaces)
    parts["[Content_Types].xml"] = _serialize(content_types, content_type_namespaces)

    output.parent.mkdir(parents=True, exist_ok=True)
    handle, temporary_name = tempfile.mkstemp(prefix="format-comments-", suffix=".docx", dir=output.parent)
    os.close(handle)
    try:
        with zipfile.ZipFile(temporary_name, "w") as target:
            written = set()
            for info in infos:
                if info.is_dir():
                    target.writestr(info, b"")
                    written.add(info.filename)
                    continue
                target.writestr(info, parts[info.filename])
                written.add(info.filename)
            if "word/comments.xml" not in written:
                target.writestr("word/comments.xml", parts["word/comments.xml"])
        os.replace(temporary_name, output)
    finally:
        if os.path.exists(temporary_name):
            os.unlink(temporary_name)

    verification = verify_comments(output)
    if not verification["valid"]:
        raise ValueError(f"Comment structural verification failed: {verification['errors']}")
    return {"status": "PASS", "output": str(output.resolve()), "added": added, "verification": verification}


def verify_comments(path: Path) -> dict:
    with zipfile.ZipFile(path) as archive:
        names = set(archive.namelist())
        errors = []
        if "word/comments.xml" not in names:
            return {"valid": False, "errors": ["word/comments.xml missing"]}
        document = ET.fromstring(archive.read("word/document.xml"))
        comments = ET.fromstring(archive.read("word/comments.xml"))
        rels = ET.fromstring(archive.read("word/_rels/document.xml.rels"))
        content_types = ET.fromstring(archive.read("[Content_Types].xml"))
        comment_ids = {element.get(qn("id")) for element in comments.findall(qn("comment"))}
        starts = {element.get(qn("id")) for element in document.iter(qn("commentRangeStart"))}
        ends = {element.get(qn("id")) for element in document.iter(qn("commentRangeEnd"))}
        references = {element.get(qn("id")) for element in document.iter(qn("commentReference"))}
        for comment_id in sorted(comment_ids):
            if comment_id not in starts:
                errors.append(f"comment {comment_id}: start anchor missing")
            if comment_id not in ends:
                errors.append(f"comment {comment_id}: end anchor missing")
            if comment_id not in references:
                errors.append(f"comment {comment_id}: reference missing")
        if not any(rel.get("Type") == f"{R}/comments" for rel in rels.findall(f"{{{PR}}}Relationship")):
            errors.append("comments relationship missing")
        if not any(
            item.get("PartName") == "/word/comments.xml"
            for item in content_types.findall(f"{{{CT}}}Override")
        ):
            errors.append("comments content type override missing")
        return {"valid": not errors, "errors": errors, "comment_count": len(comment_ids)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("findings", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--author", default="排版审查")
    parser.add_argument("--initials", default="FR")
    args = parser.parse_args()
    try:
        result = add_comments(args.source, args.findings, args.out, args.author, args.initials)
    except (FileNotFoundError, KeyError, ValueError, zipfile.BadZipFile, ET.ParseError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False, indent=2))
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
